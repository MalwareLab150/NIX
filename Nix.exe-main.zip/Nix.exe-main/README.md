Nix.exe : Gdi trojan coded in C# whith bytebeat, regedit keys destruction,critical process and encrypt all the .dll in C:\windows\system32.
PLS USE A VM
